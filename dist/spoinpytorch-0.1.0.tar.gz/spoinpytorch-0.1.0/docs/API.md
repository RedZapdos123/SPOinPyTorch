# API Reference

This document provides detailed API documentation for SPOinPyTorch.

## Core Classes

### SPOAgent

The main agent class that implements the Simple Policy Optimization algorithm.

#### Constructor

```python
SPOAgent(
    state_dim: int,
    action_dim: int,
    config: dict,
    is_discrete: bool = True,
    action_low: Optional[List[float]] = None,
    action_high: Optional[List[float]] = None,
    device: str = 'cpu'
)
```

**Parameters:**
- `state_dim` (int): Dimension of the observation space
- `action_dim` (int): Dimension of the action space
- `config` (dict): Configuration dictionary containing hyperparameters
- `is_discrete` (bool): Whether the action space is discrete (default: True)
- `action_low` (List[float], optional): Lower bounds for continuous actions
- `action_high` (List[float], optional): Upper bounds for continuous actions
- `device` (str): Device to run computations on ('cpu' or 'cuda')

#### Methods

##### get_action_and_value(state, action=None)

Get action, log probability, entropy, and value estimate for given state(s).

```python
action, log_prob, entropy, value = agent.get_action_and_value(state_tensor)
```

**Parameters:**
- `state` (torch.Tensor): State tensor of shape (batch_size, state_dim)
- `action` (torch.Tensor, optional): Specific action to evaluate

**Returns:**
- `action` (torch.Tensor): Selected action(s)
- `log_prob` (torch.Tensor): Log probability of the action(s)
- `entropy` (torch.Tensor): Entropy of the action distribution
- `value` (torch.Tensor): Value estimate for the state(s)

##### get_value(state)

Get value estimate for given state(s).

```python
value = agent.get_value(state_tensor)
```

**Parameters:**
- `state` (torch.Tensor): State tensor of shape (batch_size, state_dim)

**Returns:**
- `value` (torch.Tensor): Value estimate for the state(s)

##### compute_gae(rewards, dones, values, next_value)

Compute Generalized Advantage Estimation (GAE).

```python
advantages, returns = agent.compute_gae(rewards, dones, values, next_value)
```

**Parameters:**
- `rewards` (torch.Tensor): Reward tensor of shape (num_steps, num_envs)
- `dones` (torch.Tensor): Done flags tensor of shape (num_steps, num_envs)
- `values` (torch.Tensor): Value estimates tensor of shape (num_steps, num_envs)
- `next_value` (torch.Tensor): Next state value estimates

**Returns:**
- `advantages` (torch.Tensor): Computed advantages
- `returns` (torch.Tensor): Computed returns (advantages + values)

##### update(states, actions, old_log_probs, advantages, returns)

Update the agent's policy and value networks.

```python
loss_info = agent.update(states, actions, old_log_probs, advantages, returns)
```

**Parameters:**
- `states` (torch.Tensor): Batch of states
- `actions` (torch.Tensor): Batch of actions
- `old_log_probs` (torch.Tensor): Log probabilities from behavior policy
- `advantages` (torch.Tensor): Advantage estimates
- `returns` (torch.Tensor): Target returns for value function

**Returns:**
- `loss_info` (dict): Dictionary containing loss components:
  - `policy_loss`: Policy loss value
  - `value_loss`: Value function loss
  - `entropy_loss`: Entropy bonus
  - `total_loss`: Combined loss

### Config

Configuration class containing hyperparameters for the SPO algorithm.

#### Constructor

```python
config = Config()
```

#### Attributes

- `env_name` (str): Environment name (default: "LunarLanderContinuous-v3")
- `seed` (int): Random seed (default: 17)
- `total_timesteps` (int): Total training timesteps (default: 800,000)
- `steps_per_batch` (int): Steps per training batch (default: 4096)
- `update_epochs` (int): Number of update epochs per batch (default: 13)
- `num_minibatches` (int): Number of minibatches per update (default: 64)
- `learning_rate` (float): Learning rate (default: 0.0004526471705959077)
- `gamma` (float): Discount factor (default: 0.9863912198781083)
- `gae_lambda` (float): GAE lambda parameter (default: 0.9532163174156946)
- `epsilon` (float): SPO clipping parameter (default: 0.2632559378198367)
- `entropy_coeff` (float): Entropy coefficient (default: 0.003111644391291919)
- `value_loss_coeff` (float): Value loss coefficient (default: 0.6360807434424953)
- `max_grad_norm` (float): Maximum gradient norm (default: 1.324904070587997)
- `actor_hidden_dims` (List[int]): Actor network hidden dimensions (default: [256, 256, 256])
- `critic_hidden_dims` (List[int]): Critic network hidden dimensions (default: [256, 256, 256])
- `normalize_advantages` (bool): Whether to normalize advantages (default: False)

#### Methods

##### update(new_config)

Update configuration with new values.

```python
config.update({'learning_rate': 0.001, 'gamma': 0.99})
```

##### get_dict()

Get configuration as dictionary.

```python
config_dict = config.get_dict()
```

### Actor

Neural network for the policy (actor).

#### Constructor

```python
Actor(
    state_dim: int,
    action_dim: int,
    hidden_dims: List[int] = [64, 64],
    is_discrete: bool = True
)
```

**Parameters:**
- `state_dim` (int): Input state dimension
- `action_dim` (int): Output action dimension
- `hidden_dims` (List[int]): Hidden layer dimensions
- `is_discrete` (bool): Whether action space is discrete

### Critic

Neural network for value function estimation (critic).

#### Constructor

```python
Critic(
    state_dim: int,
    hidden_dims: List[int] = [64, 64]
)
```

**Parameters:**
- `state_dim` (int): Input state dimension
- `hidden_dims` (List[int]): Hidden layer dimensions

## Utility Functions

### layer_init(layer, std=np.sqrt(2), bias_const=0.0)

Initialize neural network layer with orthogonal weights.

```python
from SPOinPyTorch.models import layer_init
layer = layer_init(nn.Linear(64, 32))
```

**Parameters:**
- `layer` (nn.Module): PyTorch layer to initialize
- `std` (float): Standard deviation for weight initialization
- `bias_const` (float): Constant value for bias initialization

**Returns:**
- `layer` (nn.Module): Initialized layer

## Usage Examples

### Basic Training Loop

```python
import torch
import gymnasium as gym
from SPOinPyTorch import SPOAgent, Config

# Setup
env = gym.make("LunarLanderContinuous-v3")
config = Config()
agent = SPOAgent(
    state_dim=8, action_dim=2, config=config.get_dict(),
    is_discrete=False, action_low=[-1, -1], action_high=[1, 1]
)

# Training loop (simplified)
state, _ = env.reset()
for step in range(config.total_timesteps):
    # Collect experience and update agent
    # See examples for complete implementation
    pass
```

### Custom Configuration

```python
from SPOinPyTorch import Config

config = Config()
config.learning_rate = 0.001
config.actor_hidden_dims = [512, 512]
config.total_timesteps = 1_000_000

agent = SPOAgent(
    state_dim=8, action_dim=2, config=config.get_dict(),
    is_discrete=False, device='cuda'
)
```
